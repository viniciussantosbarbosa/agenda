package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;

import model.DAO;
import javax.swing.border.TitledBorder;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Servicos extends JDialog {

	// JDBC
	DAO dao = new DAO();
	private Connection con;
	private PreparedStatement pst;
	private ResultSet rs;

	private final JPanel contentPanel = new JPanel();
	private JTextField txtPlaca;
	private JTextField txtValor;
	private JTextField txtOS;
	private JTextField txtID;
	private JTextField txtModelo;
	private JTextField txtCor;
	private JButton btnAdicionar;
	private JButton btnEditar;
	private JButton btnExcluir;
	private JButton btnlimpar;
	private JDateChooser txtDataOS;
	private JPanel panel_1;
	private JLabel lblNewLabel_14;
	private JTextField textField;
	private JTextField txtUser;

	// variável global que será usada para setar o nome do usuario pelo path
	// path(caminho) login -> tela principal -> serviços

	public String usuario;
	private JTextField txtTipoLavagem;
	private JLabel lblNewLabel_16;
	private JTextField txtObservacao;
	private JDateChooser txtEntrega;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Servicos dialog = new Servicos();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Servicos() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Servicos.class.getResource("/img/carro pqn.png")));
		setTitle("Lava Rapido Vini - Serviços");
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent e) {
				txtUser.setText(usuario);
			}
		});
		setBounds(100, 100, 692, 485);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Veiculo:");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(34, 88, 46, 14);
		contentPanel.add(lblNewLabel_1);

		txtModelo = new JTextField();
		txtModelo.setBounds(109, 86, 133, 20);
		contentPanel.add(txtModelo);
		txtModelo.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("Cor do veiculo:");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(24, 30, 101, 14);
		contentPanel.add(lblNewLabel_2);

		txtCor = new JTextField();
		txtCor.setBounds(109, 28, 133, 20);
		contentPanel.add(txtCor);
		txtCor.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("Placa:");
		lblNewLabel_3.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_3.setBounds(34, 55, 46, 14);
		contentPanel.add(lblNewLabel_3);

		txtPlaca = new JTextField();
		txtPlaca.setBounds(109, 55, 133, 20);
		contentPanel.add(txtPlaca);
		txtPlaca.setColumns(10);

		JLabel lblNewLabel_4 = new JLabel("Data entrega:");
		lblNewLabel_4.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_4.setBounds(29, 119, 82, 18);
		contentPanel.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("Tipo de lavagem:");
		lblNewLabel_5.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_5.setBounds(10, 155, 101, 18);
		contentPanel.add(lblNewLabel_5);

		JLabel lblNewLabel_7 = new JLabel("Valor:");
		lblNewLabel_7.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 15));
		lblNewLabel_7.setBounds(502, 399, 46, 14);
		contentPanel.add(lblNewLabel_7);

		txtValor = new JTextField();
		txtValor.setText("0");
		txtValor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		txtValor.setBounds(546, 399, 68, 20);
		contentPanel.add(txtValor);
		txtValor.setColumns(10);

		JLabel lblNewLabel_8 = new JLabel("OS:");
		lblNewLabel_8.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_8.setBounds(254, 30, 46, 14);
		contentPanel.add(lblNewLabel_8);

		txtOS = new JTextField();
		txtOS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		txtOS.setBounds(277, 28, 71, 20);
		contentPanel.add(txtOS);
		txtOS.setColumns(10);

		btnAdicionar = new JButton("");
		btnAdicionar.setBorder(null);
		btnAdicionar.setContentAreaFilled(false);
		btnAdicionar.setIcon(new ImageIcon(Servicos.class.getResource("/img/adicionar.png")));
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarOS();
			}
		});
		btnAdicionar.setBounds(239, 377, 48, 48);
		contentPanel.add(btnAdicionar);

		btnEditar = new JButton("");
		btnEditar.setBorder(null);
		btnEditar.setContentAreaFilled(false);
		btnEditar.setIcon(new ImageIcon(Servicos.class.getResource("/img/editar.png")));
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//editarOS();
			}
		});
		btnEditar.setBounds(297, 377, 48, 48);
		contentPanel.add(btnEditar);

		btnExcluir = new JButton("");
		btnExcluir.setBorder(null);
		btnExcluir.setContentAreaFilled(false);
		btnExcluir.setIcon(new ImageIcon(Servicos.class.getResource("/img/excluir contato.png")));
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//excluirOS();
			}
		});
		btnExcluir.setBounds(345, 377, 48, 48);
		contentPanel.add(btnExcluir);

		btnlimpar = new JButton("");
		btnlimpar.setContentAreaFilled(false);
		btnlimpar.setBorder(null);
		btnlimpar.setIcon(new ImageIcon(Servicos.class.getResource("/img/limpar (2).png")));
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Limpar();
			}
		});
		btnlimpar.setBounds(433, 377, 48, 48);
		contentPanel.add(btnlimpar);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}

		txtDataOS = new JDateChooser();
		txtDataOS.getCalendarButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		txtDataOS.setBounds(310, 59, 133, 20);
		contentPanel.add(txtDataOS);

		JLabel lblNewLabel_10 = new JLabel("Data OS:");
		lblNewLabel_10.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_10.setBounds(252, 61, 48, 14);
		contentPanel.add(lblNewLabel_10);

		panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Clientes", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(453, 12, 214, 98);
		contentPanel.add(panel_1);
		panel_1.setLayout(null);

		txtID = new JTextField();
		txtID.setText("1");
		txtID.setBounds(78, 67, 86, 20);
		panel_1.add(txtID);
		txtID.setColumns(10);

		JLabel lblNewLabel_9 = new JLabel("ID:");
		lblNewLabel_9.setBounds(58, 70, 46, 14);
		panel_1.add(lblNewLabel_9);

		lblNewLabel_14 = new JLabel("");
		lblNewLabel_14.setIcon(new ImageIcon(Servicos.class.getResource("/img/search pqn.png")));
		lblNewLabel_14.setBounds(156, 11, 48, 48);
		panel_1.add(lblNewLabel_14);

		textField = new JTextField();
		textField.setBounds(26, 23, 138, 20);
		panel_1.add(textField);
		textField.setColumns(10);

		JLabel lblNewLabel_15 = new JLabel("Usuario:");
		lblNewLabel_15.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_15.setBounds(525, 121, 46, 14);
		contentPanel.add(lblNewLabel_15);

		txtUser = new JTextField();
		txtUser.setEditable(false);
		txtUser.setBounds(575, 119, 92, 20);
		contentPanel.add(txtUser);
		txtUser.setColumns(10);

		txtTipoLavagem = new JTextField();
		txtTipoLavagem.setBounds(107, 155, 135, 20);
		contentPanel.add(txtTipoLavagem);
		txtTipoLavagem.setColumns(10);

		lblNewLabel_16 = new JLabel("Observação:");
		lblNewLabel_16.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		lblNewLabel_16.setBounds(24, 323, 76, 23);
		contentPanel.add(lblNewLabel_16);

		txtObservacao = new JTextField();
		txtObservacao.setBounds(24, 349, 205, 76);
		contentPanel.add(txtObservacao);
		txtObservacao.setColumns(10);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Servicos.class.getResource("/img/valor.png")));
		lblNewLabel.setBounds(619, 377, 48, 48);
		contentPanel.add(lblNewLabel);

		txtEntrega = new JDateChooser();
		txtEntrega.setBounds(107, 117, 135, 20);
		contentPanel.add(txtEntrega);
		
		JButton btnOS = new JButton("Buscar OS");
		btnOS.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				buscarOS();
			}
		});
		btnOS.setBounds(358, 27, 82, 23);
		contentPanel.add(btnOS);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setIcon(new ImageIcon(Servicos.class.getResource("/img/carro pqn.png")));
		lblNewLabel_6.setBounds(109, 326, 31, 20);
		contentPanel.add(lblNewLabel_6);
	}// fim do construtor

	/**
	 * Método para adicionar um novo usuário
	 */
	private void adicionarOS() {

		// validação do combobox
		// if(cboPerfil.getSelectedItem().equal("))
		// System.out.println

		if (txtCor.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a cor do veiculo!");
			txtCor.requestFocus();
		} else if (txtPlaca.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a placa do veiculo!");
			txtPlaca.requestFocus();
		} else if (txtModelo.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o fabricante/modelo do veiculo!");
			txtModelo.requestFocus();
		} else {

			// System.out.println("teste do botão adicionar");
			String create = "insert into servicos (corveiculo,placaveiculo,modeloveiculo,tipolavagem,valor,observacao,dataentrega,idcli) values (?,?,?,?,?,?,?,?)";
			try {

				con = dao.conectar();
				pst = con.prepareStatement(create);

				pst.setString(1, txtCor.getText());
				pst.setString(2, txtPlaca.getText());
				pst.setString(3, txtModelo.getText());
				pst.setString(4, txtTipoLavagem.getText());
				pst.setString(5, txtValor.getText());
				pst.setString(6, txtObservacao.getText());
				// Formatar o valor do JCalendar para inserção correta no MySQL
				SimpleDateFormat formatador = new SimpleDateFormat("yyyyMMdd");
				String dataFormatada = formatador.format(txtEntrega.getDate());
				pst.setString(7, dataFormatada);
				pst.setString(8, txtID.getText());
				pst.executeUpdate();
				
				
				JOptionPane.showMessageDialog(null, "Ordem de Serviço gerada com susesso!");
				Limpar();
				con.close();
				// tratamento de exceção em caso de duplicação de login
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}// fim do método novo usuário

	
	private void buscarOS() {
		// System.out.println("teste do botão buscar");
		String read = "select * from servicos where os = ?";
		try {
			con = dao.conectar();
			pst = con.prepareStatement(read);
			pst.setString(1, txtOS.getText());
			rs = pst.executeQuery();
			if (rs.next()) {
				txtOS.setText(rs.getString(1));
				// formataçao da data no componente JDateChooser
				String setarData = rs.getString(8);
				// apoio ao entedimento da lógica
				System.out.println(setarData);
				Date dataFormatada = new SimpleDateFormat("yyyy-MM-dd").parse(setarData);

				txtDataOS.setDate(dataFormatada);
				txtEntrega.setDate(dataFormatada);
				
				txtCor.setText(rs.getString(2));
				txtPlaca.setText(rs.getString(3));
				txtModelo.setText(rs.getString(4));
				txtTipoLavagem.setText(rs.getString(5));
				txtValor.setText(rs.getString(6));
				txtObservacao.setText(rs.getString(7));
				txtID.setText(rs.getString(8));
				// mostrar a caixa o checkbox (troca de senha)
				// desabilitar a caixa de senh

				btnAdicionar.setEnabled(false);


				btnEditar.setEnabled(true);
				btnExcluir.setEnabled(true);

			} else {
				JOptionPane.showMessageDialog(null, "Ordem de serviço não cadastrada! ");

				btnAdicionar.setEnabled(true);


			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}// fim do método buscar usuário
	/**
	 * método para editar os dados do usuário e exceto senha
	 */
	/*
	private void editarOS() {
		// System.out.println("teste editar");

		if (txtCor.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a cor!");
			txtCor.requestFocus();

		} else if (txtPlaca.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a placa!!");
			txtPlaca.requestFocus();

		} else if (txtModelo.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o modelo do veiculo!");
			txtModelo.requestFocus();

		} else {

			String update = "update servicos set corveiculo=?,placaveiculo=? modeloveiculo=?, tipolavagem=?,valor=?,observacao=? dataentrega=? where idcli=? ";
			try {
				con = dao.conectar();

				pst = con.prepareStatement(update);

				pst.setString(1, txtCor.getText());
				pst.setString(2, txtPlaca.getText());
				pst.setString(3, txtModelo.getText());
				pst.setString(4, txtTipoLavagem.getText());
				pst.setString(5, txtValor.getText());
				pst.setString(6, txtObservacao.getText());
				pst.setString(7, txtEntrega.getText());
				pst.setString(8, txtID.getText());

				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Dados da Ordem Serviço alterados com sucesso!");
				con.close();
				Limpar();
			} catch (Exception e) {
				System.out.println(e);
			}
		}

	}// fim do método editar usuario

	/**
	 * Método para exclusão do usuario
	 */
	/*
	private void excluirOS() {
		// System.out.println("teste excluir");

		int confirma = JOptionPane.showConfirmDialog(null, "Confirma a exclusão deste usuário?", "ATENÇÃO!",
				JOptionPane.YES_NO_OPTION);
		if (confirma == JOptionPane.YES_OPTION) {
			String delete = "delete from servicos where idcli=?";
			try {

				con = dao.conectar();

				pst = con.prepareStatement(delete);
				pst.setString(1, txtID.getText());
				pst.executeUpdate();

				Limpar();
				JOptionPane.showMessageDialog(null, "OS excluída");

			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}// fim do método excluir usuário
*/
	private void Limpar() {
		txtOS.setText(null);
		txtID.setText(null);
		txtCor.setText(null);
		txtPlaca.setText(null);
		txtModelo.setText(null);
		txtObservacao.setText(null);
		txtTipoLavagem.setText(null);
		txtEntrega.setDate(null);
		txtDataOS.setDate(null);
		txtValor.setText(null);
		txtID.setText(null);

		btnAdicionar.setEnabled(false);
		btnEditar.setEnabled(false);
		btnExcluir.setEnabled(false);

	}
}// fim do código
