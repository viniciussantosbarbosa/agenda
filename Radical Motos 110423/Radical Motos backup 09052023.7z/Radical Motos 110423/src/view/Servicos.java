package view;

import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import model.DAO;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class Servicos extends JDialog {
	
	DAO dao = new DAO();
	private Connection con;
	private PreparedStatement pst;
	private ResultSet rs;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtID;
	private JPasswordField txtSenha;
	private JTextField txtNome;
	private JButton btnBuscar;
	private JButton btnCreate;
	private JButton btnDelete;
	private JButton btnUpdate;
	private JTextField txtVeiculoMarca;
	private JTextField textField_1;
	private JTextField txtEntrega;
	private JTextField txtOs;
	private JTextField txtCorVeiculo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Servicos dialog = new Servicos();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public Servicos() {
		setTitle("Ordem de serviço - Lava Rápido Vinicius");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Servicos.class.getResource("/img/carro.png")));
		setModal(true);
		setBounds(100, 100, 740, 405);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Senha");
		lblNewLabel_1.setBounds(23, 258, 46, 14);
		lblNewLabel_1.setToolTipText("Senha");
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Nome:");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(53, 53, 46, 14);
		getContentPane().add(lblNewLabel_2);
		
		txtNome = new JTextField();
		txtNome.setBounds(99, 47, 278, 20);
		getContentPane().add(txtNome);
		txtNome.setColumns(10);
		
		JButton btnLimpar = new JButton("");
		btnLimpar.setBorderPainted(false);
		btnLimpar.setBounds(251, 307, 48, 48);
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				limparCampos();
				
			}
		});
		btnLimpar.setContentAreaFilled(false);
		btnLimpar.setToolTipText("Limpar");
		btnLimpar.setIcon(new ImageIcon(Usuarios.class.getResource("/img/limpar (2).png")));
		getContentPane().add(btnLimpar);
		
		JLabel lblNewLabel = new JLabel("ID:");
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel.setBounds(607, 11, 25, 14);
		getContentPane().add(lblNewLabel);
		
		txtID = new JTextField();
		txtID.setBounds(627, 11, 86, 17);
		txtID.setEditable(false);
		getContentPane().add(txtID);
		txtID.setColumns(10);
		
		txtSenha = new JPasswordField();
		txtSenha.setBounds(67, 255, 141, 20);
		getContentPane().add(txtSenha);
		
		btnCreate = new JButton("");
		btnCreate.setEnabled(false);
		btnCreate.setBorderPainted(false);
		btnCreate.setBounds(53, 307, 48, 48);
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarUsuario();
			}
		});
		btnCreate.setContentAreaFilled(false);
		btnCreate.setIcon(new ImageIcon(Usuarios.class.getResource("/img/adicionar.png")));
		btnCreate.setToolTipText("adicionar");
		getContentPane().add(btnCreate);
		
		JLabel lblStatus = new JLabel("");
		lblStatus.setBounds(295, 184, 48, 48);
		getContentPane().add(lblStatus);
		
		
		JButton btnDelete = new JButton("");
		btnDelete.setEnabled(false);
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				excluirUsuario();
				
			}
		});
		btnDelete.setBorderPainted(false);
		btnDelete.setBounds(193, 307, 48, 48);
		btnDelete.setContentAreaFilled(false);
		btnDelete.setIcon(new ImageIcon(Usuarios.class.getResource("/img/excluir contato.png")));
		getContentPane().add(btnDelete);
		
		JLabel lblLogin = new JLabel("Login");
		lblLogin.setBounds(23, 233, 46, 14);
		getContentPane().add(lblLogin);
		
		JButton btnUpdatee = new JButton("Update");
		btnUpdatee.setEnabled(false);
		btnUpdatee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editarUsuario();
			}
		});
		btnUpdatee.setBorderPainted(false);
		btnUpdatee.setIcon(new ImageIcon(Usuarios.class.getResource("/img/update.png")));
		btnUpdatee.setBounds(131, 307, 52, 48);
		getContentPane().add(btnUpdatee);
		
		JLabel lblNewLabel_3 = new JLabel("Data __/__/__");
		lblNewLabel_3.setBounds(627, 329, 86, 37);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Veiculo/Marca:");
		lblNewLabel_4.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_4.setBounds(15, 78, 91, 14);
		getContentPane().add(lblNewLabel_4);
		
		txtVeiculoMarca = new JTextField();
		txtVeiculoMarca.setBounds(99, 76, 278, 20);
		getContentPane().add(txtVeiculoMarca);
		txtVeiculoMarca.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Placa:");
		lblNewLabel_5.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_5.setBounds(60, 138, 39, 14);
		getContentPane().add(lblNewLabel_5);
		
		textField_1 = new JTextField();
		textField_1.setBounds(99, 136, 278, 20);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Entrega/Horas:");
		lblNewLabel_6.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_6.setBounds(15, 163, 79, 20);
		getContentPane().add(lblNewLabel_6);
		
		txtEntrega = new JTextField();
		txtEntrega.setBounds(99, 164, 278, 20);
		getContentPane().add(txtEntrega);
		txtEntrega.setColumns(10);
		
		JComboBox cboTipoLavagem = new JComboBox();
		cboTipoLavagem.setModel(new DefaultComboBoxModel(new String[] {"", "Ducha Simples", "Ducha Completa", "Lavagem Completa", "Ducha com Cera"}));
		cboTipoLavagem.setBounds(109, 195, 278, 22);
		getContentPane().add(cboTipoLavagem);
		
		JLabel lblNewLabel_7 = new JLabel("Tipo de lavagem:");
		lblNewLabel_7.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_7.setBounds(10, 194, 96, 20);
		getContentPane().add(lblNewLabel_7);
		
		txtOs = new JTextField();
		txtOs.setEditable(false);
		txtOs.setBounds(509, 11, 86, 17);
		getContentPane().add(txtOs);
		txtOs.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("OS:");
		lblNewLabel_8.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_8.setBounds(486, 14, 25, 14);
		getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("New label");
		lblNewLabel_9.setIcon(new ImageIcon(Servicos.class.getResource("/img/search pqn.png")));
		lblNewLabel_9.setBounds(373, 37, 48, 48);
		getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Cor veiculo:");
		lblNewLabel_10.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_10.setBounds(33, 107, 78, 14);
		getContentPane().add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("");
		lblNewLabel_11.setIcon(new ImageIcon(Servicos.class.getResource("/img/corVeiculo.png")));
		lblNewLabel_11.setBounds(193, 97, 32, 32);
		getContentPane().add(lblNewLabel_11);
		
		txtCorVeiculo = new JTextField();
		txtCorVeiculo.setBounds(99, 105, 86, 20);
		getContentPane().add(txtCorVeiculo);
		txtCorVeiculo.setColumns(10);
		
		JLabel lblNewLabel_12 = new JLabel("");
		lblNewLabel_12.setIcon(new ImageIcon(Servicos.class.getResource("/img/carro pqn.png")));
		lblNewLabel_12.setBounds(384, 76, 24, 24);
		getContentPane().add(lblNewLabel_12);
		
		JLabel lblNewLabel_13 = new JLabel("");
		lblNewLabel_13.setIcon(new ImageIcon(Servicos.class.getResource("/img/form g.png")));
		lblNewLabel_13.setBounds(384, 132, 24, 24);
		getContentPane().add(lblNewLabel_13);
		
		JLabel lblNewLabel_14 = new JLabel("");
		lblNewLabel_14.setBounds(23, 53, 700, 14);
		getContentPane().add(lblNewLabel_14);

	}// fim do construtor
	
	
	
	/**
	 * método para adicionar um contato no banco
	 */

	private void adicionarUsuario() {
		// System.out.println("Teste do botão adicionar");
		String create = "insert into usuarios(nome,login,senha) values(?,?,?)";
		try { 
			con = dao.conectar();
			pst = con.prepareStatement(create);
			pst.setString(1,txtLogin2.getText());
			pst.setString(2,txtNome.getText());
			pst.setString(3,txtSenha.getText());
			pst.executeUpdate();
			JOptionPane.showMessageDialog(null, "Usuario adicionado com sucesso");
			// limpar campos
			limparCampos();
			con.close();
		} catch (Exception e){
			System.out.println(e);
		}
	}// fim adicionar usuários
	
	private void editarUsuario() {
		//System.out.println("teste do botão editar");
		//validação de campos obrigatórios
		if (txtNome.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o nome!");
			txtNome.requestFocus();
		} else if (txtVeiculoMarca.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o Veiculo e Marca!");
			txtVeiculoMarca.requestFocus();
		} else {
			//lógica principal (CRUD Update)
			//Criando uma variável do tipo String que irá receber a query
			String update = "update usuarios set nome =?, fone=?,email=? where id = ?";
			
			try {
				//abrir a conexão com o banco
				con = dao.conectar();
				//preparar a query(substituir ????)
				pst = con.prepareStatement(update);
				pst.setString(1, txtNome.getText());
				pst.setString(2, txtSenha.getText());
				pst.setString(3, txtLogin2.getText());
				pst.setString(4, txtID.getText());
				//executar o update no banco
				pst.executeUpdate();
				//confirmar para o usuário
				JOptionPane.showMessageDialog(null, "Dado de usuarios alterado com sucesso");
				//NUNCA esquecer de fechar a conexão
				con.close();
				//limpar os campos
				limparCampos();
				
			} catch (Exception e) {
				System.out.println(e);
			}
			
		}
	}
	
	/**
	 * Método responsável por excluir um contato
	 */
	private void excluirUsuario() {
		
		//System.out.println("teste do botão excluir");
		//confirmar exclusão
		//A variável confirma captura a opção escolhida no JOption
		
		int confirma = JOptionPane.showConfirmDialog(null, "Confirma a exclusão deste usuario?", "ATENÇÃO!", JOptionPane.YES_NO_OPTION);
		if(confirma == JOptionPane.YES_OPTION) {
			String delete = "delete from usuarios where id=?";
			try {
				//abrir conexão
				con = dao.conectar();
				//preparar query (instrução sql)
				pst = con.prepareStatement(delete);
				pst.setString(1,txtID.getText());
				pst.executeUpdate();
				//limpar os campos
				limparCampos();
				JOptionPane.showMessageDialog(null, "usuario excluído");
				
						// fechar a conexão(IMPORTANTE!!)
			} catch (Exception e) {
			System.out.println(e);
		}
	}
	}

	
	private void limparCampos() {
		txtID.setText(null);
		txtNome.setText(null);
		txtVeiculoMarca.setText(null);
		txtSenha.setText(null);
		
		// setar botões
				btnCreate.setEnabled(false);
				btnUpdate.setEnabled(false);
				btnBuscar.setEnabled(true);
				btnDelete.setEnabled(false);

	}// fim do método limparCampos()
}//fim do código
