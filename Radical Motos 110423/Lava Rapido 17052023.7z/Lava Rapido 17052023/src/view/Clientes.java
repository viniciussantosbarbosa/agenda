package view;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import model.DAO;
import java.awt.Toolkit;

public class Clientes extends JDialog {

	DAO dao = new DAO();
	private Connection con;
	private PreparedStatement pst;
	private ResultSet rs;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtID;
	private JTextField txtNome;
	private JTextField txtTelefone;
	private JButton btnCreate;
	private JButton btnBuscar;
	private JButton btnEditar;
	private JButton btnExcluir;

	private final JPanel contentPanel = new JPanel();
	private JTextField txtEndereco;
	private JTextField txtCep;
	private JTextField txtCidade;
	private JTextField txtBairro;
	private JComboBox cboUf;
	private JLabel lblNewLabel_4;
	private JTextField txtNumero;
	private JLabel lblNewLabel_9;
	private JTextField txtComplemento;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Clientes dialog = new Clientes();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public Clientes() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Clientes.class.getResource("/img/carro pqn.png")));
		getContentPane().setBackground(Color.WHITE);
		getContentPane().setEnabled(false);
		setTitle("Lava Rapido Vini - Clientes");
		setResizable(false);
		setModal(true);
		setBounds(100, 100, 632, 408);
		getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("ID ");
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 13));
		lblNewLabel.setBounds(58, 13, 46, 14);
		getContentPane().add(lblNewLabel);

		txtID = new JTextField();
		txtID.setEditable(false);
		txtID.setBounds(111, 11, 86, 20);
		getContentPane().add(txtID);
		txtID.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Nome:");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(58, 48, 46, 14);
		getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_3 = new JLabel("Endereço:");
		lblNewLabel_3.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 13));
		lblNewLabel_3.setBounds(42, 131, 62, 14);
		getContentPane().add(lblNewLabel_3);

		txtNome = new JTextField();
		txtNome.setBounds(111, 42, 292, 20);
		getContentPane().add(txtNome);
		txtNome.setColumns(10);

		txtTelefone = new JTextField();
		txtTelefone.setBounds(111, 73, 292, 20);
		getContentPane().add(txtTelefone);
		txtTelefone.setColumns(10);

		btnCreate = new JButton("");
		btnCreate.setContentAreaFilled(false);
		btnCreate.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnCreate.setBorderPainted(false);
		btnCreate.setToolTipText("Adicionar");
		btnCreate.setBorder(null);
		btnCreate.setIcon(new ImageIcon(Usuarios.class.getResource("/img/adicionar.png")));
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarCliente();
			}
		});
		btnCreate.setBounds(111, 291, 48, 48);
		getContentPane().add(btnCreate);

		btnBuscar = new JButton("");
		btnBuscar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnBuscar.setContentAreaFilled(false);
		btnBuscar.setBorderPainted(false);
		btnBuscar.setIcon(new ImageIcon(Usuarios.class.getResource("/img/pesquisar.png")));
		btnBuscar.setToolTipText("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buscarCliente();
			}
		});
		btnBuscar.setBounds(413, 30, 48, 48);
		getContentPane().add(btnBuscar);

		btnEditar = new JButton("");
		btnEditar.setContentAreaFilled(false);
		btnEditar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnEditar.setBorderPainted(false);
		btnEditar.setIcon(new ImageIcon(Usuarios.class.getResource("/img/editar.png")));
		btnEditar.setToolTipText("Editar");
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editarCliente();

			}

		});
		btnEditar.setBounds(165, 291, 48, 48);
		getContentPane().add(btnEditar);

		btnExcluir = new JButton("");
		btnExcluir.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnExcluir.setContentAreaFilled(false);
		btnExcluir.setBorderPainted(false);
		btnExcluir.setIcon(new ImageIcon(Usuarios.class.getResource("/img/excluir contato.png")));
		btnExcluir.setToolTipText("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				excluirCliente();
			}
		});
		btnExcluir.setBounds(223, 291, 48, 48);
		getContentPane().add(btnExcluir);

		JButton btnLimpar = new JButton("");
		btnLimpar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLimpar.setContentAreaFilled(false);
		btnLimpar.setBorderPainted(false);
		btnLimpar.setIcon(new ImageIcon(Usuarios.class.getResource("/img/limpar (2).png")));
		btnLimpar.setToolTipText("Limpar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Limpar();
			}
		});
		btnLimpar.setBounds(307, 291, 48, 48);
		getContentPane().add(btnLimpar);

		getRootPane().setDefaultButton(btnBuscar);
	

		JLabel lblNewLabel_2 = new JLabel("Telefone:");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 13));
		lblNewLabel_2.setBounds(48, 81, 56, 14);
		getContentPane().add(lblNewLabel_2);

		txtEndereco = new JTextField();
		txtEndereco.setBounds(111, 129, 292, 20);
		getContentPane().add(txtEndereco);
		txtEndereco.setColumns(10);

		JLabel lblNewLabel_5 = new JLabel("CEP:");
		lblNewLabel_5.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 13));
		lblNewLabel_5.setBounds(68, 106, 46, 14);
		getContentPane().add(lblNewLabel_5);

		txtCep = new JTextField();
		txtCep.setBounds(111, 104, 86, 20);
		getContentPane().add(txtCep);
		txtCep.setColumns(10);

		cboUf = new JComboBox();
		cboUf.setModel(new DefaultComboBoxModel(
				new String[] { "", "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA",
						"PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO" }));
		cboUf.setBounds(455, 193, 62, 22);
		getContentPane().add(cboUf);

		JLabel lblNewLabel_6 = new JLabel("UF:");
		lblNewLabel_6.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 13));
		lblNewLabel_6.setBounds(413, 196, 25, 14);
		getContentPane().add(lblNewLabel_6);

		JButton btnBuscarcep = new JButton("");
		btnBuscarcep.setContentAreaFilled(false);
		btnBuscarcep.setIcon(new ImageIcon(Clientes.class.getResource("/img/check 2.png")));
		btnBuscarcep.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buscarCep();
			}
		});
		btnBuscarcep.setBounds(207, 104, 46, 20);
		getContentPane().add(btnBuscarcep);

		JLabel lblNewLabel_7 = new JLabel("Bairro:");
		lblNewLabel_7.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 13));
		lblNewLabel_7.setBounds(58, 162, 46, 14);
		getContentPane().add(lblNewLabel_7);

		txtBairro = new JTextField();
		txtBairro.setBounds(111, 160, 292, 20);
		getContentPane().add(txtBairro);
		txtBairro.setColumns(10);

		JLabel lblNewLabel_8 = new JLabel("Cidade:");
		lblNewLabel_8.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 13));
		lblNewLabel_8.setBounds(58, 193, 46, 14);
		getContentPane().add(lblNewLabel_8);

		txtCidade = new JTextField();
		txtCidade.setBounds(111, 191, 292, 20);
		getContentPane().add(txtCidade);
		txtCidade.setColumns(10);

		lblNewLabel_4 = new JLabel("Número:");
		lblNewLabel_4.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 13));
		lblNewLabel_4.setBounds(413, 226, 56, 14);
		getContentPane().add(lblNewLabel_4);

		txtNumero = new JTextField();
		txtNumero.setBounds(471, 226, 46, 22);
		getContentPane().add(txtNumero);
		txtNumero.setColumns(10);

		lblNewLabel_9 = new JLabel("Complemento:");
		lblNewLabel_9.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 13));
		lblNewLabel_9.setBounds(20, 222, 94, 14);
		getContentPane().add(lblNewLabel_9);

		txtComplemento = new JTextField();
		txtComplemento.setBounds(111, 222, 292, 20);
		getContentPane().add(txtComplemento);
		txtComplemento.setColumns(10);

		JLabel lblNewLabel_10 = new JLabel("New label");
		lblNewLabel_10.setIcon(new ImageIcon(Clientes.class.getResource("/img/casa.png")));
		lblNewLabel_10.setBounds(413, 115, 48, 48);
		getContentPane().add(lblNewLabel_10);

	}// fim do construtor

	/**
	 * Método que busca endereço automaticamente em um web service
	 */

	private void buscarCep() {
		String logradouro = "";
		String tipoLogradouro = "";
		String cep = txtCep.getText();
		String resultado = null;
		try {
			URL url = new URL("http://cep.republicavirtual.com.br/web_cep.php?cep=" + cep + "&formato=xml");
			SAXReader xml = new SAXReader();
			Document documento = xml.read(url);
			Element root = documento.getRootElement();
			for (Iterator<Element> it = root.elementIterator(); it.hasNext();) {
				Element element = it.next();
				if (element.getQualifiedName().equals("cidade")) {
					txtCidade.setText(element.getText());
				}
				if (element.getQualifiedName().equals("bairro")) {
					txtBairro.setText(element.getText());
				}
				if (element.getQualifiedName().equals("uf")) {
					cboUf.setSelectedItem(element.getText());
				}
				if (element.getQualifiedName().equals("tipo_logradouro")) {
					tipoLogradouro = element.getText();
				}
				if (element.getQualifiedName().equals("logradouro")) {
					logradouro = element.getText();
				}
				if (element.getQualifiedName().equals("resultado")) {
					resultado = element.getText();
					// System.out.println(resultado);
					if (resultado.equals("0")) {
						JOptionPane.showMessageDialog(null, "CEP inexistente!");
					}

				} // acha a tag com o nome resultado.

			}

			txtEndereco.setText(tipoLogradouro + " " + logradouro);
		} catch (

		Exception e) {
			System.out.println(e);
		}
	}

	private void adicionarCliente() {

		// validação do combobox
		// if(cboPerfil.getSelectedItem().equal("))
		// System.out.println

		if (txtNome.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o nome do cliente!");
			txtNome.requestFocus();
		} else if (txtTelefone.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Digite o telefone do cliente!");
			txtTelefone.requestFocus();
		} else if (txtCep.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Digite o CEP do cliente!");
			txtCep.requestFocus();
		} else if (txtNumero.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Digite o número do cliente!");
			txtNumero.requestFocus();
		}else if (txtEndereco.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Digite o endereço do cliente!");
			txtEndereco.requestFocus();
		}else if (txtBairro.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Digite o bairro do cliente!");
			txtBairro.requestFocus();
		} else {
		

			// System.out.println("teste do botão adicionar");
			String create = "insert into clientes(nome,telefone,endereco,cidade,cep,bairro,uf,complemento,numero) values(?,?,?,?,?,?,?,?,?)";
			try {

				con = dao.conectar();
				pst = con.prepareStatement(create);
				pst.setString(1, txtNome.getText());
				pst.setString(2, txtTelefone.getText());
				pst.setString(3, txtEndereco.getText());
				pst.setString(4, txtCidade.getText());
				pst.setString(5, txtCep.getText());
				pst.setString(6, txtBairro.getText());
				pst.setString(7, cboUf.getSelectedItem().toString());
				pst.setString(8, txtComplemento.getText());
				pst.setString(9, txtNumero.getText());
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Cliente adicionado com sucesso!");
				Limpar();
				con.close();

				// tratamento de exceção em caso de duplicação de login
			} catch (java.sql.SQLIntegrityConstraintViolationException e1) {
				JOptionPane.showMessageDialog(null,
						"Cliente não adicionado.\nJá possui um cliente com ");
			} catch (Exception e1) {
				System.out.println(e1);
			} // tratamento de exceção em caso de duplicação de login
		}
			
 }// fim do método novo cliente

	/**
	 * Método para buscar novo usuario
	 */
	private void buscarCliente() {
		// System.out.println("teste do botão buscar");
		String read = "select * from clientes where nome = ?";
		try {
			con = dao.conectar();
			pst = con.prepareStatement(read);
			pst.setString(1, txtNome.getText());
			rs = pst.executeQuery();
			if (rs.next()) {
				txtID.setText(rs.getString(1));
				txtNome.setText(rs.getString(2));
				txtTelefone.setText(rs.getString(3));
				txtEndereco.setText(rs.getString(4));
				txtCidade.setText(rs.getString(5));
				txtCep.setText(rs.getString(6));
				txtBairro.setText(rs.getString(7));
				cboUf.setSelectedItem(rs.getString(8));
				txtComplemento.setText(rs.getString(9));
				txtNumero.setText(rs.getString(10));

				// mostrar a caixa o checkbox (troca de senha)

				// desabilitar a caixa de senha

				btnCreate.setEnabled(false);

				btnBuscar.setEnabled(false);

				btnEditar.setEnabled(true);
				btnExcluir.setEnabled(true);

			} else {
				JOptionPane.showMessageDialog(null, "Cliente não cadastrado!");

				btnCreate.setEnabled(true);

				btnBuscar.setEnabled(false);

			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}// fim do método buscar usuário

	/**
	 * método para editar os dados do usuário e senha
	 */
	private void editarCliente() {
		// System.out.println("teste editar");

		if (txtNome.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o nome do cliente!");
			txtNome.requestFocus();
		}
		if (txtNumero.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o número do cliente!");
			txtNumero.requestFocus();
		}
		if (txtEndereco.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o número do cliente!");
			txtEndereco.requestFocus();
		}
		if (txtBairro.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o bairro do cliente!");
			txtBairro.requestFocus();
		}
			else {

			String update = "update clientes set nome=?,telefone=?,endereco=?,cidade=?,cep=?,bairro=?,uf=?,complemento=?,numero=? where idcli=? ";
			try {
				con = dao.conectar();

				pst = con.prepareStatement(update);

				pst.setString(1, txtNome.getText());
				pst.setString(2, txtTelefone.getText());
				pst.setString(3, txtEndereco.getText());
				pst.setString(4, txtCidade.getText());
				pst.setString(5, txtCep.getText());
				pst.setString(6, txtBairro.getText());
				pst.setString(7, cboUf.getSelectedItem().toString());
				pst.setString(8, txtComplemento.getText());
				pst.setString(9, txtNumero.getText());
				pst.setString(10, txtID.getText());

				pst.executeUpdate();
				Limpar();
				JOptionPane.showMessageDialog(null, "Dados do Cliente editados com sucesso");
				con.close();
				// tratamento de exceção em caso de duplicação de login
			} catch (java.sql.SQLIntegrityConstraintViolationException e2) {
				JOptionPane.showMessageDialog(null,
						"Cliente não adicionado.\nJá possui um veículo cadatrastado com a mesma placa.");
			} catch (Exception e2) {
				System.out.println(e2);

			}

		}

	}// fim do método editar usuario

	/**
	 * Método para exclusão do usuario
	 */
	private void excluirCliente() {
		// System.out.println("teste excluir");

		int confirma = JOptionPane.showConfirmDialog(null, "Confirma a exclusão deste Cliente?", "ATENÇÃO!",
				JOptionPane.YES_NO_OPTION);
		if (confirma == JOptionPane.YES_OPTION) {
			String delete = "delete from clientes where idcli=?";
			try {

				con = dao.conectar();

				pst = con.prepareStatement(delete);
				pst.setString(1, txtID.getText());
				pst.executeUpdate();

				Limpar();
				JOptionPane.showMessageDialog(null, "Cliente excluído");

			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	private void Limpar() {
		txtID.setText(null);
		txtNome.setText(null);
		txtTelefone.setText(null);
		txtEndereco.setText(null);
		txtCep.setText(null);
		txtBairro.setText(null);
		txtCep.setText(null);
		txtCidade.setText(null);
		txtNumero.setText(null);
		txtComplemento.setText(null);
		cboUf.setSelectedItem("");

		btnCreate.setEnabled(false);
		btnEditar.setEnabled(false);
		btnBuscar.setEnabled(true);
		btnExcluir.setEnabled(false);
		txtNome.requestFocus();

	}// fim do construtor
}// fim do código
