package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;

import model.DAO;
import javax.swing.border.TitledBorder;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Font;
import java.awt.Toolkit;

public class Servicos extends JDialog {

	// JDBC
	DAO dao = new DAO();
	private Connection con;
	private PreparedStatement pst;
	private ResultSet rs;

	private final JPanel contentPanel = new JPanel();
	private JTextField txtPlaca;
	private JTextField txtValor;
	private JTextField txtOS;
	private JTextField txtID;
	private JTextField txtModelo;
	private JTextField txtCor;
	private JButton btnAdicionar;
	private JButton btnEditar;
	private JButton btnExcluir;
	private JButton btnlimpar;
	private JButton btnBuscar;
	private JDateChooser txtDataOS;
	private JTextField txtID2;
	private JLabel lblNewLabel_12;
	private JLabel lblNewLabel_13;
	private JTextField txtUsuario;
	private JPanel panel_1;
	private JLabel lblNewLabel_14;
	private JTextField textField;
	private JTextField txtUser;

	// variável global que será usada para setar o nome do usuario pelo path
	// path(caminho) login -> tela principal -> serviços

	public String usuario;
	private JTextField txtTipoLavagem;
	private JLabel lblNewLabel_16;
	private JTextField txtObservacao;
	private JDateChooser txtEntrega;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Servicos dialog = new Servicos();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Servicos() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Servicos.class.getResource("/img/carro pqn.png")));
		setTitle("Lava Rapido Vini - Serviços");
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent e) {
				txtUser.setText(usuario);
			}
		});
		setBounds(100, 100, 692, 399);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Veiculo:");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(10, 112, 46, 14);
		contentPanel.add(lblNewLabel_1);

		txtModelo = new JTextField();
		txtModelo.setBounds(60, 109, 133, 20);
		contentPanel.add(txtModelo);
		txtModelo.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("Cor do veiculo:");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(10, 53, 101, 14);
		contentPanel.add(lblNewLabel_2);

		txtCor = new JTextField();
		txtCor.setBounds(92, 53, 101, 20);
		contentPanel.add(txtCor);
		txtCor.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("Placa:");
		lblNewLabel_3.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_3.setBounds(10, 80, 46, 14);
		contentPanel.add(lblNewLabel_3);

		txtPlaca = new JTextField();
		txtPlaca.setBounds(50, 78, 143, 20);
		contentPanel.add(txtPlaca);
		txtPlaca.setColumns(10);

		JLabel lblNewLabel_4 = new JLabel("Data entrega:");
		lblNewLabel_4.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_4.setBounds(10, 144, 82, 18);
		contentPanel.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("Tipo de lavagem:");
		lblNewLabel_5.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_5.setBounds(10, 173, 101, 18);
		contentPanel.add(lblNewLabel_5);

		JLabel lblNewLabel_7 = new JLabel("Valor:");
		lblNewLabel_7.setBounds(325, 242, 46, 14);
		contentPanel.add(lblNewLabel_7);

		txtValor = new JTextField();
		txtValor.setText("0");
		txtValor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		txtValor.setBounds(359, 239, 86, 20);
		contentPanel.add(txtValor);
		txtValor.setColumns(10);

		JLabel lblNewLabel_8 = new JLabel("OS:");
		lblNewLabel_8.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_8.setBounds(147, 11, 46, 14);
		contentPanel.add(lblNewLabel_8);

		txtOS = new JTextField();
		txtOS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		txtOS.setBounds(172, 8, 57, 20);
		contentPanel.add(txtOS);
		txtOS.setColumns(10);

		btnAdicionar = new JButton("");
		btnAdicionar.setBorder(null);
		btnAdicionar.setContentAreaFilled(false);
		btnAdicionar.setIcon(new ImageIcon(Servicos.class.getResource("/img/adicionar.png")));
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarOS();
			}
		});
		btnAdicionar.setBounds(204, 302, 48, 48);
		contentPanel.add(btnAdicionar);

		btnEditar = new JButton("");
		btnEditar.setBorder(null);
		btnEditar.setContentAreaFilled(false);
		btnEditar.setIcon(new ImageIcon(Servicos.class.getResource("/img/editar.png")));
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//editarOS();
			}
		});
		btnEditar.setBounds(265, 302, 48, 48);
		contentPanel.add(btnEditar);

		btnExcluir = new JButton("");
		btnExcluir.setBorder(null);
		btnExcluir.setContentAreaFilled(false);
		btnExcluir.setIcon(new ImageIcon(Servicos.class.getResource("/img/excluir contato.png")));
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//excluirOS();
			}
		});
		btnExcluir.setBounds(323, 302, 48, 48);
		contentPanel.add(btnExcluir);

		btnlimpar = new JButton("");
		btnlimpar.setContentAreaFilled(false);
		btnlimpar.setBorder(null);
		btnlimpar.setIcon(new ImageIcon(Servicos.class.getResource("/img/limpar (2).png")));
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Limpar();
			}
		});
		btnlimpar.setBounds(399, 302, 48, 48);
		contentPanel.add(btnlimpar);

		btnBuscar = new JButton("");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//buscarCliente();
			}
		});
		btnBuscar.setBorder(null);
		btnBuscar.setContentAreaFilled(false);
		btnBuscar.setIcon(new ImageIcon(Servicos.class.getResource("/img/search pqn.png")));
		btnBuscar.setBounds(188, 39, 48, 48);
		contentPanel.add(btnBuscar);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}

		getRootPane().setDefaultButton(btnBuscar);

		txtDataOS = new JDateChooser();
		txtDataOS.getCalendarButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		txtDataOS.setBounds(536, 173, 108, 20);
		contentPanel.add(txtDataOS);

		JLabel lblNewLabel_10 = new JLabel("Data OS:");
		lblNewLabel_10.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_10.setBounds(478, 175, 48, 14);
		contentPanel.add(lblNewLabel_10);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Usuarios", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(453, 11, 214, 98);
		contentPanel.add(panel);
		panel.setLayout(null);

		lblNewLabel_12 = new JLabel("ID:");
		lblNewLabel_12.setBounds(25, 73, 15, 14);
		panel.add(lblNewLabel_12);

		txtID2 = new JTextField();
		txtID2.setBounds(50, 70, 86, 20);
		panel.add(txtID2);
		txtID2.setColumns(10);

		lblNewLabel_13 = new JLabel("");
		lblNewLabel_13.setIcon(new ImageIcon(Servicos.class.getResource("/img/search pqn.png")));
		lblNewLabel_13.setBounds(156, 11, 48, 48);
		panel.add(lblNewLabel_13);

		txtUsuario = new JTextField();
		txtUsuario.setBounds(25, 24, 139, 20);
		panel.add(txtUsuario);
		txtUsuario.setColumns(10);

		panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Clientes", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(239, 11, 214, 98);
		contentPanel.add(panel_1);
		panel_1.setLayout(null);

		txtID = new JTextField();
		txtID.setText("1");
		txtID.setBounds(78, 67, 86, 20);
		panel_1.add(txtID);
		txtID.setColumns(10);

		JLabel lblNewLabel_9 = new JLabel("ID:");
		lblNewLabel_9.setBounds(58, 70, 46, 14);
		panel_1.add(lblNewLabel_9);

		lblNewLabel_14 = new JLabel("");
		lblNewLabel_14.setIcon(new ImageIcon(Servicos.class.getResource("/img/search pqn.png")));
		lblNewLabel_14.setBounds(156, 11, 48, 48);
		panel_1.add(lblNewLabel_14);

		textField = new JTextField();
		textField.setBounds(26, 23, 138, 20);
		panel_1.add(textField);
		textField.setColumns(10);

		JLabel lblNewLabel_15 = new JLabel("Usuario:");
		lblNewLabel_15.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_15.setBounds(10, 11, 46, 14);
		contentPanel.add(lblNewLabel_15);

		txtUser = new JTextField();
		txtUser.setEditable(false);
		txtUser.setBounds(61, 8, 61, 20);
		contentPanel.add(txtUser);
		txtUser.setColumns(10);

		txtTipoLavagem = new JTextField();
		txtTipoLavagem.setBounds(107, 171, 122, 20);
		contentPanel.add(txtTipoLavagem);
		txtTipoLavagem.setColumns(10);

		lblNewLabel_16 = new JLabel("Observação:");
		lblNewLabel_16.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 14));
		lblNewLabel_16.setBounds(24, 214, 76, 23);
		contentPanel.add(lblNewLabel_16);

		txtObservacao = new JTextField();
		txtObservacao.setBounds(24, 239, 169, 59);
		contentPanel.add(txtObservacao);
		txtObservacao.setColumns(10);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Servicos.class.getResource("/img/valor.png")));
		lblNewLabel.setBounds(455, 227, 48, 48);
		contentPanel.add(lblNewLabel);

		txtEntrega = new JDateChooser();
		txtEntrega.setBounds(85, 142, 108, 20);
		contentPanel.add(txtEntrega);
	}// fim do construtor

	/**
	 * Método para adicionar um novo usuário
	 */
	private void adicionarOS() {

		// validação do combobox
		// if(cboPerfil.getSelectedItem().equal("))
		// System.out.println

		if (txtCor.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a cor do veiculo!");
			txtCor.requestFocus();
		} else if (txtPlaca.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a placa do veiculo!");
			txtPlaca.requestFocus();
		} else if (txtModelo.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o fabricante/modelo do veiculo!");
			txtModelo.requestFocus();
		} else {

			// System.out.println("teste do botão adicionar");
			String create = "insert into servicos (corveiculo,placaveiculo,modeloveiculo,tipolavagem,valor,observacao,dataentrega,idcli) values (?,?,?,?,?,?,?,?)";
			try {

				con = dao.conectar();
				pst = con.prepareStatement(create);

				pst.setString(1, txtCor.getText());
				pst.setString(2, txtPlaca.getText());
				pst.setString(3, txtModelo.getText());
				pst.setString(4, txtTipoLavagem.getText());
				pst.setString(5, txtValor.getText());
				pst.setString(6, txtObservacao.getText());
				// Formatar o valor do JCalendar para inserção correta no MySQL
				SimpleDateFormat formatador = new SimpleDateFormat("yyyyMMdd");
				String dataFormatada = formatador.format(txtEntrega.getDate());
				pst.setString(7, dataFormatada);
				pst.setString(8, txtID.getText());
				pst.executeUpdate();
				
				
				JOptionPane.showMessageDialog(null, "Ordem de Serviço gerada com susesso!");
				Limpar();
				con.close();
				// tratamento de exceção em caso de duplicação de login
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}// fim do método novo usuário

	/*
	private void buscarCliente() {
		// System.out.println("teste do botão buscar");
		String read = "select * from servicos where corveiculo = ?";
		try {
			con = dao.conectar();
			pst = con.prepareStatement(read);
			pst.setString(1, txtCor.getText());
			rs = pst.executeQuery();
			if (rs.next()) {
				txtOS.setText(rs.getString(1));
				// formataçao da data no componente JDateChooser
				String setarData = rs.getString(11);
				// apoio ao entedimento da lógica
				System.out.println(setarData);
				Date dataFormatada = new SimpleDateFormat("yyyy-MM-dd").parse(setarData);

				txtDataOS.setDate(dataFormatada);

				txtCor.setText(rs.getString(1));
				txtPlaca.setText(rs.getString(2));
				txtModelo.setText(rs.getString(3));
				txtTipoLavagem.setText(rs.getString(4));
				txtValor.setText(rs.getString(5));
				txtObservacao.setText(rs.getString(6));
				txtEntrega.setText(rs.getString(7));
				txtID.setText(rs.getString(8));
				// mostrar a caixa o checkbox (troca de senha)
				// desabilitar a caixa de senh

				btnAdicionar.setEnabled(false);

				btnBuscar.setEnabled(false);

				btnEditar.setEnabled(true);
				btnExcluir.setEnabled(true);

			} else {
				JOptionPane.showMessageDialog(null, "Ordem de serviço não cadastrada! ");

				btnAdicionar.setEnabled(true);

				btnBuscar.setEnabled(false);

			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}// fim do método buscar usuário
*/
	/**
	 * método para editar os dados do usuário e exceto senha
	 */
	/*
	private void editarOS() {
		// System.out.println("teste editar");

		if (txtCor.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a cor!");
			txtCor.requestFocus();

		} else if (txtPlaca.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe a placa!!");
			txtPlaca.requestFocus();

		} else if (txtModelo.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o modelo do veiculo!");
			txtModelo.requestFocus();

		} else {

			String update = "update servicos set corveiculo=?,placaveiculo=? modeloveiculo=?, tipolavagem=?,valor=?,observacao=? dataentrega=? where idcli=? ";
			try {
				con = dao.conectar();

				pst = con.prepareStatement(update);

				pst.setString(1, txtCor.getText());
				pst.setString(2, txtPlaca.getText());
				pst.setString(3, txtModelo.getText());
				pst.setString(4, txtTipoLavagem.getText());
				pst.setString(5, txtValor.getText());
				pst.setString(6, txtObservacao.getText());
				pst.setString(7, txtEntrega.getText());
				pst.setString(8, txtID.getText());

				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Dados da Ordem Serviço alterados com sucesso!");
				con.close();
				Limpar();
			} catch (Exception e) {
				System.out.println(e);
			}
		}

	}// fim do método editar usuario

	/**
	 * Método para exclusão do usuario
	 */
	/*
	private void excluirOS() {
		// System.out.println("teste excluir");

		int confirma = JOptionPane.showConfirmDialog(null, "Confirma a exclusão deste usuário?", "ATENÇÃO!",
				JOptionPane.YES_NO_OPTION);
		if (confirma == JOptionPane.YES_OPTION) {
			String delete = "delete from servicos where idcli=?";
			try {

				con = dao.conectar();

				pst = con.prepareStatement(delete);
				pst.setString(1, txtID.getText());
				pst.executeUpdate();

				Limpar();
				JOptionPane.showMessageDialog(null, "OS excluída");

			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}// fim do método excluir usuário
*/
	private void Limpar() {
		txtID.setText(null);
		txtCor.setText(null);
		txtPlaca.setText(null);
		txtModelo.setText(null);
		//txtEntrega.setText(null);
		txtValor.setText(null);
		txtID.setText(null);

		btnAdicionar.setEnabled(false);
		btnEditar.setEnabled(false);
		btnBuscar.setEnabled(true);
		btnExcluir.setEnabled(false);

	}
}// fim do código
