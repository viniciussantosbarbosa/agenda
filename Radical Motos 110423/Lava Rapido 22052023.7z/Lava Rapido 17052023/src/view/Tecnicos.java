package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.ImageIcon;

public class Tecnicos extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Tecnicos dialog = new Tecnicos();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Tecnicos() {
		setTitle("Lava Rapido Vini - Técnicos");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Tecnicos.class.getResource("/img/carro pqn.png")));
		setBounds(100, 100, 688, 379);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JButton btnNewButton = new JButton("");
			btnNewButton.setContentAreaFilled(false);
			btnNewButton.setBorder(null);
			btnNewButton.setIcon(new ImageIcon(Tecnicos.class.getResource("/img/adicionar.png")));
			btnNewButton.setBounds(38, 271, 48, 48);
			contentPanel.add(btnNewButton);
		}
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.setBorder(null);
		btnNewButton_1.setContentAreaFilled(false);
		btnNewButton_1.setIcon(new ImageIcon(Tecnicos.class.getResource("/img/editar.png")));
		btnNewButton_1.setBounds(96, 271, 48, 48);
		contentPanel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.setBorder(null);
		btnNewButton_2.setContentAreaFilled(false);
		btnNewButton_2.setIcon(new ImageIcon(Tecnicos.class.getResource("/img/excluir contato.png")));
		btnNewButton_2.setBounds(154, 271, 48, 48);
		contentPanel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("");
		btnNewButton_3.setContentAreaFilled(false);
		btnNewButton_3.setBorder(null);
		btnNewButton_3.setIcon(new ImageIcon(Tecnicos.class.getResource("/img/limpar (2).png")));
		btnNewButton_3.setBounds(256, 271, 48, 48);
		contentPanel.add(btnNewButton_3);
		
		textField = new JTextField();
		textField.setBounds(73, 24, 86, 20);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Nome:");
		lblNewLabel.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel.setBounds(27, 26, 46, 14);
		contentPanel.add(lblNewLabel);
		
		textField_1 = new JTextField();
		textField_1.setBounds(73, 55, 86, 20);
		contentPanel.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Telefone:");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(19, 55, 56, 14);
		contentPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Apelido:");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(19, 88, 46, 14);
		contentPanel.add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setBounds(73, 86, 86, 20);
		contentPanel.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(Tecnicos.class.getResource("/img/tecnicos.png")));
		lblNewLabel_3.setBounds(475, 24, 128, 128);
		contentPanel.add(lblNewLabel_3);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
	}
}
