package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;

public class Servicos extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField txtNome;
	private JTextField txtPlaca;
	private JTextField textField;
	private JTextField txtValor;
	private JTextField txtOs;
	private JTextField txtID;
	private JTextField txtVeiculo;
	private JTextField txtCor;
	private JComboBox cboTipoLavagem;
	private JComboBox cboEstadoVeiculo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Servicos dialog = new Servicos();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Servicos() {
		setBounds(100, 100, 769, 392);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nome:");
		lblNewLabel.setBounds(50, 63, 46, 14);
		contentPanel.add(lblNewLabel);
		
		txtNome = new JTextField();
		txtNome.setBounds(82, 60, 86, 20);
		contentPanel.add(txtNome);
		txtNome.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Veiculo:");
		lblNewLabel_1.setBounds(50, 88, 46, 14);
		contentPanel.add(lblNewLabel_1);
		
		txtVeiculo = new JTextField();
		txtVeiculo.setBounds(92, 85, 86, 20);
		contentPanel.add(txtVeiculo);
		txtVeiculo.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Cor do veiculo:");
		lblNewLabel_2.setBounds(35, 115, 86, 14);
		contentPanel.add(lblNewLabel_2);
		
		txtCor = new JTextField();
		txtCor.setBounds(115, 116, 86, 20);
		contentPanel.add(txtCor);
		txtCor.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Placa:");
		lblNewLabel_3.setBounds(50, 147, 46, 14);
		contentPanel.add(lblNewLabel_3);
		
		txtPlaca = new JTextField();
		txtPlaca.setBounds(92, 144, 86, 20);
		contentPanel.add(txtPlaca);
		txtPlaca.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Entrega/Horas");
		lblNewLabel_4.setBounds(50, 172, 71, 14);
		contentPanel.add(lblNewLabel_4);
		
		textField = new JTextField();
		textField.setBounds(125, 175, 86, 20);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		cboTipoLavagem = new JComboBox();
		cboTipoLavagem.setBounds(115, 206, 119, 22);
		contentPanel.add(cboTipoLavagem);
		
		JLabel lblNewLabel_5 = new JLabel("Tipo de lavagem:");
		lblNewLabel_5.setBounds(23, 210, 86, 14);
		contentPanel.add(lblNewLabel_5);
		
		cboEstadoVeiculo = new JComboBox();
		cboEstadoVeiculo.setBounds(115, 238, 119, 22);
		contentPanel.add(cboEstadoVeiculo);
		
		JLabel lblNewLabel_6 = new JLabel("Estado veiculo:");
		lblNewLabel_6.setBounds(23, 242, 86, 14);
		contentPanel.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Valor:");
		lblNewLabel_7.setBounds(494, 242, 46, 14);
		contentPanel.add(lblNewLabel_7);
		
		txtValor = new JTextField();
		txtValor.setBounds(525, 239, 86, 20);
		contentPanel.add(txtValor);
		txtValor.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("OS:");
		lblNewLabel_8.setBounds(547, 11, 46, 14);
		contentPanel.add(lblNewLabel_8);
		
		txtOs = new JTextField();
		txtOs.setBounds(570, 8, 86, 20);
		contentPanel.add(txtOs);
		txtOs.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("ID:");
		lblNewLabel_9.setBounds(525, 36, 46, 14);
		contentPanel.add(lblNewLabel_9);
		
		txtID = new JTextField();
		txtID.setBounds(557, 33, 86, 20);
		contentPanel.add(txtID);
		txtID.setColumns(10);
		
		JButton btnAdicionar = new JButton("adicionar");
		btnAdicionar.setBounds(62, 309, 89, 23);
		contentPanel.add(btnAdicionar);
		
		JButton btnEditar = new JButton("Editar");
		btnEditar.setBounds(161, 309, 89, 23);
		contentPanel.add(btnEditar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.setBounds(260, 309, 89, 23);
		contentPanel.add(btnExcluir);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.setBounds(359, 309, 89, 23);
		contentPanel.add(btnlimpar);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
	}//fim do construtor
	
	

	/**
	 * Método para adicionar um novo usuário
	 */
	private void adicionarUsuario() {

		// validação do combobox
		// if(cboPerfil.getSelectedItem().equal("))
		// System.out.println

		String capturaSenha = new String(txtSenha.getPassword());

		if (txtNome.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o login");
			txtNome.requestFocus();
		}else if (txtVeiculo.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o login");
			txtVeiculo.requestFocus();
		}  else if (txtCor.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o login");
			txtCor.requestFocus();
		} else if (txtPlaca.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o login");
			txtPlaca.requestFocus();
		}else if (cboTipoLavagem.getSelectedItem().equals("")) {
			JOptionPane.showMessageDialog(null, "Digite o perfil");
			cboPerfil.requestFocus();
		} else {

			// System.out.println("teste do botão adicionar");
			String create = "insert into usuarios(nome,login,senha,perfil) values(?,?,md5(?),?)";
			try {

				con = dao.conectar();
				pst = con.prepareStatement(create);
				pst.setString(1, txtNome.getText());
				pst.setString(2, txtLogin.getText());
				pst.setString(3, capturaSenha);
				pst.setString(4, cboPerfil.getSelectedItem().toString());
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Usuário adicionado com sucesso");
				Limpar();
				con.close();
				// tratamento de exceção em caso de duplicação de login
			} catch (java.sql.SQLIntegrityConstraintViolationException e1) {
				JOptionPane.showMessageDialog(null, "Usuário não adicionado.\nEste login já está sendo utilizado");
			} catch (Exception e2) {
				System.out.println(e2);
			}
		}
	}// fim do método novo usuário
	
	/**
	 * método para editar os dados do usuário e exceto senha
	 */
	private void editarUsuario() {
		// System.out.println("teste editar");

		if (txtLogin.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Informe o login");
			txtLogin.requestFocus();
			txtSenha.requestFocus();

		} else if (cboPerfil.getSelectedItem().equals("")) {
			JOptionPane.showMessageDialog(null, "Digite o perfil");
			cboPerfil.requestFocus();
		} else {

			String update = "update usuarios set nome=?,login=?,perfil=? where iduser=? ";
			try {
				con = dao.conectar();

				pst = con.prepareStatement(update);

				pst.setString(1, txtNome.getText());
				pst.setString(2, txtLogin.getText());
				pst.setString(3, cboPerfil.getSelectedItem().toString());
				pst.setString(4, txtID.getText());

				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Dados do usuário editado com sucesso");
				con.close();
				Limpar();
			} catch (java.sql.SQLIntegrityConstraintViolationException e1) {
				JOptionPane.showMessageDialog(null, "Usuário não adicionado.\nEste login já está sendo utilizado");
			} catch (Exception e2) {
				System.out.println(e2);
			}
		}

	}// fim do método editar usuario

	/**
	 * Método para exclusão do usuario
	 */
	private void excluirUsuario() {
		// System.out.println("teste excluir");

		int confirma = JOptionPane.showConfirmDialog(null, "Confirma a exclusão deste usuário?", "ATENÇÃO!",
				JOptionPane.YES_NO_OPTION);
		if (confirma == JOptionPane.YES_OPTION) {
			String delete = "delete from usuarios where iduser=?";
			try {

				con = dao.conectar();

				pst = con.prepareStatement(delete);
				pst.setString(1, txtID.getText());
				pst.executeUpdate();

				Limpar();
				JOptionPane.showMessageDialog(null, "Usuário excluído");

			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}//fim do método excluir usuário
	
	private void Limpar() {
		txtID.setText(null);
		txtNome.setText(null);
		txtLogin.setText(null);
		txtSenha.setText(null);
		cboPerfil.setSelectedItem(null);

		btnCreate.setEnabled(false);
		btnEditar.setEnabled(false);
		btnBuscar.setEnabled(true);
		chkSenha.setVisible(false);
		btnExcluir.setEnabled(false);
		txtSenha.setBackground(Color.white);
		txtSenha.setEditable(true);
		scrollPane.setVisible(false);

	}
	
	
	
}//fim do código

